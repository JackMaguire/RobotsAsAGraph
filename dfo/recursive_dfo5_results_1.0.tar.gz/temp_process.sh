#!/bin/bash

mkdir tmp || exit 1

for key in 0 1 2 3 4 5 6 7; do
    echo $key > tmp/$key
    grep FINAL recursive_dfo5_results_1.0/iter_1749_benchmarks/full.$key/*.log | awk '{print $2 + ($3/11) + int($4 == "MoveResult.YOU_WIN_GAME") }' | sort -gr >> tmp/$key
done

paste -d, tmp/*

rm -r tmp
