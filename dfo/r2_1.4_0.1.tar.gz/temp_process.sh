#!/bin/bash

mkdir tmp || exit 1

for key in 0 1 2 3 4 5 6 7; do
    echo $key > tmp/$key
    grep FINAL r2_1.4_0.1/iter_2503_benchmarks/full.$key/*.log | awk '{print $2 + ($3/11) + int($4 == "MoveResult.YOU_WIN_GAME") }' | sort -gr >> tmp/$key
done

paste -d, tmp/*

rm -r tmp
