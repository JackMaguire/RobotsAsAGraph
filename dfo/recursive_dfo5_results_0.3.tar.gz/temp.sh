#!/bin/bash

output_dirname="recursive_dfo5_results_0.3/iter_1146_benchmarks"

model="recursive_dfo5_results_0.3/iter_1146.h5"

for rd in 7 6 5 4 3 2 1 0; do
    mkdir -p $output_dirname/full.$rd 2>/dev/null
done

{
    start=1 #dummy for consistancy
    for rd in 7 6 5 4 3 2 1 0; do
	for x in {1..500}; do
	    echo $model $rd $((start+22)) $x $(basename $model)
	done
    done
} | xargs -n 5 -P `grep processor /proc/cpuinfo | wc -l` bash -c 'python3 model_play_game.py --model $0 --recursion_depth $1 --start_level 1 --stop_level 999 2>/dev/null 1>'$output_dirname'/full.$1/$4.$3.log'

# nconv2.3.h5.checkpoint.h5 10 67 2  train/nconv2.3.h5.checkpoint.h5
# 4                         3  2  1  0 
